package com.company;

public class Main {

    public static void main(String[] args) {

        SimpleCalculator calculator = new SimpleCalculator();
        calculator.setFirstNumber(5.0);
        calculator.setSecondNumber(4);
        System.out.println("add "+ calculator.getAdditionResult());
        System.out.println("sub " + calculator.getSubtractionResult());
        System.out.println("div "+ calculator.getDivisionResult());
        System.out.println("mut " + calculator.getMultiplicationResult());
        calculator.setFirstNumber(5.0);
        calculator.setSecondNumber(0);
        System.out.println("div " + calculator.getDivisionResult());
        System.out.println("mut "+ calculator.getMultiplicationResult());


    }
}
